package org.shifat.securityservices.service;

import java.awt.*;

/**
 * Simple "service" for providing style information.
 */
public class StyleService {

    public static Font HEADING_FONT = new Font("Sans Serif", Font.BOLD, 24);

}
